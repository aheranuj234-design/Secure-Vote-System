/**
 * main.js — E-Voting System Client Scripts
 * Demonstrates: JavaScript variables, functions, loops, conditions, DOM manipulation
 */

// ── DOMContentLoaded ────────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", function () {
  initTheme();
  initNavToggle();
  initFlashAutoClose();
  animateStatNumbers();
  initProgressBars();
});

// ── Dark / Light Mode ────────────────────────────────────────────────────────

function initTheme() {
  // Read saved preference from localStorage (default: light)
  var saved = localStorage.getItem("evote-theme") || "light";
  applyTheme(saved);

  // Wire up both toggle buttons (desktop + mobile)
  var toggleDesktop = document.getElementById("themeToggle");
  var toggleMobile  = document.getElementById("themeToggleMobile");

  if (toggleDesktop) toggleDesktop.addEventListener("click", function () { toggleTheme(); });
  if (toggleMobile)  toggleMobile.addEventListener("click",  function () { toggleTheme(); });
}

function applyTheme(theme) {
  var html = document.documentElement;
  html.setAttribute("data-theme", theme);

  // Update both icon elements
  var icons = ["themeIcon", "themeIconMobile"];
  icons.forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.textContent = theme === "dark" ? "☀️" : "🌙";
  });
}

function toggleTheme() {
  var current = document.documentElement.getAttribute("data-theme") || "light";
  var next    = current === "dark" ? "light" : "dark";
  applyTheme(next);
  localStorage.setItem("evote-theme", next);
}

// ── Navigation Toggle (mobile) ───────────────────────────────────────────────

function initNavToggle() {
  var toggle = document.getElementById("navToggle");
  var links  = document.getElementById("navLinks");
  if (!toggle || !links) return;

  toggle.addEventListener("click", function () {
    links.classList.toggle("open");
  });

  // Close nav when a link is clicked
  links.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () {
      links.classList.remove("open");
    });
  });
}

// ── Auto-close flash messages ────────────────────────────────────────────────

function initFlashAutoClose() {
  var alerts = document.querySelectorAll(".alert");
  alerts.forEach(function (alert) {
    setTimeout(function () {
      if (alert && alert.parentNode) {
        alert.style.transition = "opacity 0.4s ease";
        alert.style.opacity    = "0";
        setTimeout(function () {
          if (alert.parentNode) alert.parentNode.removeChild(alert);
        }, 400);
      }
    }, 5000);
  });
}

// ── Animate stat counter numbers ─────────────────────────────────────────────

function animateStatNumbers() {
  var statEls = document.querySelectorAll(".stat-number, .stats-card-value");
  statEls.forEach(function (el) {
    var rawText = el.textContent.trim();
    var hasPct  = rawText.indexOf("%") !== -1;
    var rawNum  = parseFloat(rawText.replace("%", "").replace(",", ""));

    if (isNaN(rawNum) || rawNum === 0) return;

    var start    = 0;
    var end      = rawNum;
    var duration = 1000;
    var startTs  = null;

    function step(ts) {
      if (!startTs) startTs = ts;
      var progress = Math.min((ts - startTs) / duration, 1);
      var eased    = 1 - Math.pow(1 - progress, 3);
      var current  = Math.round(start + (end - start) * eased * 100) / 100;
      el.textContent = hasPct ? current + "%" : current;
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.textContent = rawText;
      }
    }

    requestAnimationFrame(step);
  });
}

// ── Animate result bar fills ─────────────────────────────────────────────────

function initProgressBars() {
  var fills = document.querySelectorAll(".result-bar-fill");
  if (fills.length === 0) return;

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        var bar    = entry.target;
        var target = bar.getAttribute("data-target") || bar.style.width;
        setTimeout(function () {
          bar.style.width = target + (target.indexOf("%") === -1 ? "%" : "");
        }, 100);
        observer.unobserve(bar);
      }
    });
  }, { threshold: 0.1 });

  fills.forEach(function (fill) {
    var target = parseFloat(fill.style.width);
    fill.style.width = "0%";
    fill.setAttribute("data-target", target);
    observer.observe(fill);
  });
}

// ── Password visibility toggle ───────────────────────────────────────────────

function togglePassword(inputId) {
  var input  = document.getElementById(inputId);
  var button = input ? input.nextElementSibling : null;
  if (!input) return;

  if (input.type === "password") {
    input.type = "text";
    if (button) button.textContent = "🙈";
  } else {
    input.type = "password";
    if (button) button.textContent = "👁";
  }
}

// ── Active nav link highlight ────────────────────────────────────────────────

(function highlightActiveNavLink() {
  var currentPath = window.location.pathname;
  var navLinks    = document.querySelectorAll(".nav-link");

  navLinks.forEach(function (link) {
    var href = link.getAttribute("href");
    if (href && currentPath.startsWith(href) && href !== "/") {
      link.style.color      = "var(--primary)";
      link.style.background = "var(--primary-light)";
    }
  });
})();
